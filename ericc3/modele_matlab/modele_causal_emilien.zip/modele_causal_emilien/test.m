A=5
B=5*pi;
K=2;
tau=3;