Ar Drone Controller
-------------------

2013 Patrick Christmann
Website: http://miniapps.free.fr

This software is distributed in the hope that it will be useful, but 
this software is provided "as is" WITHOUT ANY WARRANTY.
In no event the Author shall be liable to DIRECT, INDIRECT, 
INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES.

